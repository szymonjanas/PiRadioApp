cd `dirname "$0"`
./PiRadioApp \
    -res resources \ 
    -sha :8081 
    